from flask import Flask, render_template, request
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import nltk
import ssl

# Create an unverified SSL context
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that requires certificate verification
    ssl._create_default_https_context = _create_unverified_https_context

# Download the VADER lexicon
nltk.download('vader_lexicon')

app = Flask(__name__)

@app.route('/', methods=["GET", "POST"])
def main():
    message = ''
    if request.method == "POST":
        inp = request.form.get("inp")
        sid = SentimentIntensityAnalyzer()
        score = sid.polarity_scores(inp)

        if score["neg"] != 0:
            message = "Negative 😓😓"
        else:
            message = "Positive 😇😇"

    return render_template('home.html', message=message)

if __name__ == '__main__':
    app.run(debug=True)
